import base64
import os

def Cmd_run(Data):
    Return_Cmd=''
    Exec_Cmd=os.popen(Data)
    Exec_Cmd=Exec_Cmd.read()
    for Cmd in Exec_Cmd:
        Return_Cmd=Return_Cmd+Cmd
    return Return_Cmd
a=Cmd_run("cd")
print("a:"+a)